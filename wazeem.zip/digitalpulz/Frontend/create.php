<?php
session_start();
if (isset($_POST['Name'])) {
    
    $Code = $_POST['Code'];
    $Name = $_POST['Name'];
    $Danger = $_POST['Danger'];
    $Reorder = $_POST['Reorder'];


    $url = "http://localhost:8092/BASE_API/rest/Product";
  
    $data = array(
        "product" => array(
            "productCode" => $Code,
            "productName" => $Name,
            "dangerLevel" => $Danger,
            "reorderLevel" => $Reorder,
            "active" => true,
            "user" => 1 
        )
    );  
    
    $options = array(
        'http' => array( 
            'header' => "Content-Type: application/json\r\n" .
                        "Authorization: Basic aGlzOmhpczEyMzQ1\r\n" .
                        "X-tenantID: D0001\r\n",
            'method' => 'POST',  
            'content' => json_encode($data)  
        )
    );
    
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    $result = json_decode($response, true); 

    if ($result) {
        header('location:index.php');
        $_SESSION['success_mg'] = "Insert Success";
        die();
    } else {
        echo $result;
    }
} else {
    header('location:index.php');
}
