<?php
session_start();

$url = 'http://localhost:8092/BASE_API/rest/Product';

$options = array(
  'http' => array(
    'header' => "Authorization: Basic aGlzOmhpczEyMzQ1\r\n" .
                "X-tenantID: D0001\r\n"
  )
);
$context = stream_context_create($options);
$data = file_get_contents($url, false, $context);
$result = json_decode($data, true);

?>


<!DOCTYPE html>
<html lang="en">

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>PHP API CRUD opearation - bootstrapfriendly</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">

</head>

<body>
  <div class="container">
    <div class="table-responsive">
      <div class="table-wrapper">
        <div class="table-title">
          <div class="row">
            <div class="col-sm-8">
              <h2><b>Product Details</b></h2>
            </div>
            <div class="col-sm-4">
              <a href="add.php" class="btn btn-primary add-new"><i class="fa fa-plus"></i> Add Product</a>
            </div>
            <div class="col-md-12">

              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php if (isset($_SESSION['success_mg'])) {
                  echo  $_SESSION['success_mg'];
                } ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
            
          </div>
        </div>
        <?php
        if (isset($result)) {
        ?>
          <form action="" method="POST" id="myform">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Reorder Level</th>
                  <th>Danger Level</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php foreach ($result as $list) {

                ?>
                  <tr>
                    <td><?php echo $list['productCode'] ?></td>
                    <td><?php echo $list['productName'] ?></td>
                    <td><?php echo $list['reorderLevel'] ?></td>
                    <td><?php echo $list['dangerLevel'] ?></td>
                    <td>
                      <a href="edit.php?id=<?php echo $list['id'] ?>" class=" btn btn-primary" title="Edit" data-toggle="tooltip">Edit</a>
                      <a href="delete.php?id=<?php echo $list['id'] ?>" class=" btn btn-danger" title="Delete" data-toggle="tooltip">Delete</a>
                    </td>
                  </tr>

                <?php

                } ?>


              </tbody>
            </table>
          </form>

        <?php

        } else {
          //echo $result['data'];
        }

        ?>

      </div>
    </div>
  </div>

</body>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>


</html>