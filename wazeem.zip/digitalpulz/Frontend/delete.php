<?php
session_start();
if (isset($_GET['id'])) {

  $url = "http://localhost:8092/BASE_API/rest/Product";
  $id =  $_GET['id'];  

  $options = array(
    'http' => array(
      'header' => "Authorization: Basic aGlzOmhpczEyMzQ1\r\n" .
        "X-tenantID: D0001\r\n" .
        "Content-Type: application/json\r\n",
      'method' => 'DELETE'
    )
  );

  $context = stream_context_create($options);
  $data = file_get_contents($url . '/' . $id, false, $context);
  $result = json_decode($data, true);
  echo ("<script>console.log('PHP: " . $result . "');</script>");

  if ($data === false) {
    $_SESSION['success_mg'] = "Delete Success";
  header('location:index.php');
  } else {

    print_r($result);
  }
} else {
  header('location:index.php');
}
