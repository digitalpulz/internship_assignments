<?php
if (isset($_GET['id']) && isset($_GET['id']) > 0) {

    $id = $_GET['id'];
    $url = 'http://localhost:8092/BASE_API/rest/Product/' . $id;

    $options = array(
        'http' => array(
            'header' => "Authorization: Basic aGlzOmhpczEyMzQ1\r\n" .
                "X-tenantID: D0001\r\n"
        )
    );
    $context = stream_context_create($options);
    $data = file_get_contents($url, false, $context);
    $result = json_decode($data, true);
} else {
    echo "id not found";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>CRUD opearation</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container-lg">
        <div class="table-responsive">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-12">
                            <h2>Edit <b>Product</b></h2>
                        </div>
                    </div>
                </div>
                <?php
                if (isset($result)) {
                ?>
                    <form action="update.php" method="POST" id="myform">
                        <table class="table table-bordered">
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $result['id'] ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Code</label>
                                <input type="text" name="Code" value="<?php echo $result['productCode'] ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Name</label>
                                <input type="text" name="Name" value="<?php echo $result['productName'] ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Danger Level</label>
                                <input type="text" name="Danger" value="<?php echo $result['dangerLevel'] ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Reorder Level</label>
                                <input type="text" name="Reorder" value="<?php echo $result['reorderLevel'] ?>" class="form-control">
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">Update</button>
                    </form>
                <?php
                } else {
                    //echo $result['data'];
                }
                ?>

            </div>
        </div>
    </div>
</body>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</html>