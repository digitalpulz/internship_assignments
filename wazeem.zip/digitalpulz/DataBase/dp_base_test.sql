-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2023 at 04:15 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dp_base_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `b_grn`
--

CREATE TABLE `b_grn` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT 0,
  `addition` double NOT NULL,
  `deduction` double NOT NULL,
  `discount` double DEFAULT 0,
  `discountRs` bit(1) NOT NULL,
  `grossAmt` double NOT NULL,
  `invoiceNo` varchar(255) DEFAULT NULL,
  `netAmt` double NOT NULL,
  `purchaseOrderNo` varchar(255) DEFAULT NULL,
  `rcvDate` datetime DEFAULT NULL,
  `totDiscount` double DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `b_grn_item`
--

CREATE TABLE `b_grn_item` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT 0,
  `balQty` double NOT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `costPrice` float NOT NULL,
  `discount` float NOT NULL,
  `discountRs` bit(1) NOT NULL,
  `expDate` datetime DEFAULT NULL,
  `foc` double NOT NULL,
  `packQty` double NOT NULL,
  `quantity` double NOT NULL,
  `sellingPrice` float NOT NULL,
  `wSalePrice` double NOT NULL,
  `grn` bigint(20) UNSIGNED NOT NULL,
  `product` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `b_invoice`
--

CREATE TABLE `b_invoice` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT 0,
  `invoiceNumber` varchar(255) DEFAULT NULL,
  `isTotDiscountRs` bit(1) NOT NULL,
  `recievedAmount` double NOT NULL,
  `totDiscountAmount` double DEFAULT 0,
  `totalAmount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `b_invoice_items`
--

CREATE TABLE `b_invoice_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT 0,
  `amount` double DEFAULT 0,
  `discount` double DEFAULT 0,
  `isDiscountRs` bit(1) NOT NULL,
  `particulars` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT 0,
  `rate` double NOT NULL,
  `invoice` bigint(20) UNSIGNED NOT NULL,
  `stock` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `b_product`
--

CREATE TABLE `b_product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT 0,
  `dangerLevel` int(11) NOT NULL,
  `productCode` varchar(255) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `reorderLevel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `b_product`
--

INSERT INTO `b_product` (`id`, `version`, `active`, `created_at`, `created_by`, `updated_at`, `updated_by`, `dangerLevel`, `productCode`, `productName`, `reorderLevel`) VALUES
(1, 7, b'0', '2023-05-15 23:08:36', 1, '2023-05-16 00:39:18', 1, 11, '11', '111', 111),
(2, 2, b'0', '2023-05-15 23:08:47', 1, '2023-05-16 19:24:56', 1, 10, 'P0002', 'test', 222),
(3, 1, b'1', '2023-05-16 00:28:17', 1, '2023-05-16 19:25:52', 1, 21321, '1231', '3213', 13),
(4, 2, b'0', '2023-05-16 00:28:27', 1, '2023-05-16 19:01:42', 1, 4, '4', '4', 4),
(5, 1, b'1', '2023-05-16 19:20:44', 1, '2023-05-16 19:20:53', 1, 1122, '11122', '11122', 11122);

-- --------------------------------------------------------

--
-- Table structure for table `b_stock`
--

CREATE TABLE `b_stock` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT 0,
  `expDate` datetime DEFAULT NULL,
  `quantity` double NOT NULL,
  `remainq` double NOT NULL,
  `sellingPrice` float NOT NULL,
  `grnItem` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `b_grn`
--
ALTER TABLE `b_grn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b_grn_item`
--
ALTER TABLE `b_grn_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK198doh60ds4mwibc6k2boeryo` (`grn`),
  ADD KEY `FKd2m7hjtkgqk5myfgkb3j8nl81` (`product`);

--
-- Indexes for table `b_invoice`
--
ALTER TABLE `b_invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b_invoice_items`
--
ALTER TABLE `b_invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKeejgoo8y2s0slpmmlu7539j78` (`invoice`),
  ADD KEY `FKrsfmxwyg3coi3py8ykoyedvoj` (`stock`);

--
-- Indexes for table `b_product`
--
ALTER TABLE `b_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b_stock`
--
ALTER TABLE `b_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKmxujxtc5aj79086auu5vi1om8` (`grnItem`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `b_grn`
--
ALTER TABLE `b_grn`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `b_grn_item`
--
ALTER TABLE `b_grn_item`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `b_invoice`
--
ALTER TABLE `b_invoice`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `b_invoice_items`
--
ALTER TABLE `b_invoice_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `b_product`
--
ALTER TABLE `b_product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `b_stock`
--
ALTER TABLE `b_stock`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `b_grn_item`
--
ALTER TABLE `b_grn_item`
  ADD CONSTRAINT `FK198doh60ds4mwibc6k2boeryo` FOREIGN KEY (`grn`) REFERENCES `b_grn` (`id`),
  ADD CONSTRAINT `FKd2m7hjtkgqk5myfgkb3j8nl81` FOREIGN KEY (`product`) REFERENCES `b_product` (`id`);

--
-- Constraints for table `b_invoice_items`
--
ALTER TABLE `b_invoice_items`
  ADD CONSTRAINT `FKeejgoo8y2s0slpmmlu7539j78` FOREIGN KEY (`invoice`) REFERENCES `b_invoice` (`id`),
  ADD CONSTRAINT `FKrsfmxwyg3coi3py8ykoyedvoj` FOREIGN KEY (`stock`) REFERENCES `b_stock` (`id`);

--
-- Constraints for table `b_stock`
--
ALTER TABLE `b_stock`
  ADD CONSTRAINT `FKmxujxtc5aj79086auu5vi1om8` FOREIGN KEY (`grnItem`) REFERENCES `b_grn_item` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
