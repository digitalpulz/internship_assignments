This is a basic Springboot application to be used as a base for new projects.

(configFile contains the connection details to the database.)

**Requirements**

- Run on any Springboot IDE
- Springboot Framework 2.2.0
- Java 8
- Allocated Port for Spring boot APP - port 8092 (can be changed via application.properties file)

**Steps**

1) Copy the folder named 'configFiles' to 'C:\' in Windows or '/home/ubuntu/' in linux
    * if you are running on Linux go to 'MasterService.java' and update the path replacing ubuntu with your namespace

2) Create a mysql database with name 'dp_base_test'
    * mysql port should be 3306, if you have any passwords for mysql update the 'base.properties' in the 'configFiles' folder with the url, username and password. Do not change anything else.

3) API will require a basic auth credential to connect with backend and a header field as follows

    Basic Auth :
        Username : his
        Password : his12345

    Following are the headers

```
    Authorization : Basic aGlzOmhpczEyMzQ1
    X-tenantID : D0001
```
example url: http://localhost:8092/BASE_API/rest/Product

4) Sample JSON Objects are as follows

//POST Object
```
{
    "product" : {
        "productCode" : "P0001",
        "productName" : "test",
        "dangerLevel" : 10,
        "reorderLevel" : 100,
        "active": true,
        "user": 1
    }
}
```

//PUT Object
```
{
    "product" : {
        "productCode" : "P0002",
        "productName" : "testUpdate",
        "dangerLevel" : 20,
        "reorderLevel" : 200,
        "active": true,
        "user": 2
    }
}
```

//DELETE Object

```
{
    "product" : {
        "user": 2
    }
}
```

**Assignment**

Create a Frontend PHP Project with a Interfaces to use the CRUD Api given by the Backend_base project.

- User should be able to add a new product
- User should be able to see added products on a table
- User should be able to update all fields of a selected product (Product Name, Product Code, Danger level, Reorder Level, active)
- User should be able to delete a product, on deletion the entry should be removed from the table.
- Have confirmations and validation where necessary (optional)

Once completed commit the frontend code to the 'internship_assignment' gitlab repository on a new branch with your name.

