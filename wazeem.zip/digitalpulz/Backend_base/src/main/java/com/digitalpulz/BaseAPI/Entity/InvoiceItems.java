package com.digitalpulz.BaseAPI.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "b_invoice_items")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class InvoiceItems extends BaseEntityAudit{

	private String particulars;

	private double rate;

	@Column(columnDefinition = "int default 0")
	private double qty;
	
	@Column(columnDefinition = "double default 0")
	private double amount;	

	@Column(columnDefinition = "double default 0")
	private double discount;

	@JsonProperty
	private boolean isDiscountRs;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invoice", nullable = false)
	@JsonIgnoreProperties("items")
	private Invoice invoice;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stock", nullable = false)
	@JsonIgnoreProperties("items")
	private Stock stock;

	public String getParticulars() {
		return particulars;
	}

	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getQty() {
		return qty;
	}

	public void setQty(double qty) {
		this.qty = qty;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public boolean isDiscountRs() {
		return isDiscountRs;
	}

	public void setDiscountRs(boolean isDiscountRs) {
		this.isDiscountRs = isDiscountRs;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}
		
}
