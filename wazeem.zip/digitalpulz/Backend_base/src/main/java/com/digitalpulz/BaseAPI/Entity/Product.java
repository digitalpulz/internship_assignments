package com.digitalpulz.BaseAPI.Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "b_product")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Product extends BaseEntityAudit{

	private String productCode;
	
	private int reorderLevel;
	
	private int dangerLevel;
	
	private String productName;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "product")
	@JsonIgnoreProperties("product")
	private Set<Grnitem> grnitem = new HashSet<Grnitem>();

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public int getReorderLevel() {
		return reorderLevel;
	}

	public void setReorderLevel(int reorderLevel) {
		this.reorderLevel = reorderLevel;
	}

	public int getDangerLevel() {
		return dangerLevel;
	}

	public void setDangerLevel(int dangerLevel) {
		this.dangerLevel = dangerLevel;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Set<Grnitem> getGrnitem() {
		return grnitem;
	}

	public void setGrnitem(Set<Grnitem> grnitem) {
		this.grnitem = grnitem;
	}
	
}
