package com.digitalpulz.BaseAPI.Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "b_invoice")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Invoice extends BaseEntityAudit {

	private String invoiceNumber;

	private double recievedAmount;

	private double totalAmount;

	@Column(columnDefinition = "double default 0")
	private double totDiscountAmount;
	
	@JsonProperty
	private boolean isTotDiscountRs;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "invoice")
	@JsonIgnoreProperties("invoice")
	private Set<InvoiceItems> items = new HashSet<>();

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public double getRecievedAmount() {
		return recievedAmount;
	}

	public void setRecievedAmount(double recievedAmount) {
		this.recievedAmount = recievedAmount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public double getTotDiscountAmount() {
		return totDiscountAmount;
	}

	public void setTotDiscountAmount(double totDiscountAmount) {
		this.totDiscountAmount = totDiscountAmount;
	}

	public boolean isTotDiscountRs() {
		return isTotDiscountRs;
	}

	public void setTotDiscountRs(boolean isTotDiscountRs) {
		this.isTotDiscountRs = isTotDiscountRs;
	}

	public Set<InvoiceItems> getItems() {
		return items;
	}

	public void setItems(Set<InvoiceItems> items) {
		this.items = items;
	}
	
	
}
