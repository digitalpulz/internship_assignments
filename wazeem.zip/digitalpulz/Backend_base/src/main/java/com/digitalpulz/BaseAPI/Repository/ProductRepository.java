package com.digitalpulz.BaseAPI.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.digitalpulz.BaseAPI.Entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{

	@Query("FROM Product p  where p.active=true")
	Optional<List<Product>> getAllActiveProducts();

}
