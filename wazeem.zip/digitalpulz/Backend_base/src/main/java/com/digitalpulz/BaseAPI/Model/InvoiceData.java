package com.digitalpulz.BaseAPI.Model;

public class InvoiceData extends BaseEntityData{

	private String invoiceNumber;

	private double recievedAmount;

	private double totalAmount;

	private double totDiscountAmount;
	
	private boolean totDiscountRs;

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public double getRecievedAmount() {
		return recievedAmount;
	}

	public void setRecievedAmount(double recievedAmount) {
		this.recievedAmount = recievedAmount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public double getTotDiscountAmount() {
		return totDiscountAmount;
	}

	public void setTotDiscountAmount(double totDiscountAmount) {
		this.totDiscountAmount = totDiscountAmount;
	}

	public boolean isTotDiscountRs() {
		return totDiscountRs;
	}

	public void setTotDiscountRs(boolean totDiscountRs) {
		this.totDiscountRs = totDiscountRs;
	}
	
	
}
