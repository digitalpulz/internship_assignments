package com.digitalpulz.BaseAPI.Model;

import java.util.Date;

public class GrnitemData extends BaseEntityData {

	private double quantity;

	private double foc;

	private float costPrice;

	private float sellingPrice;

	private float discount;

	private Date expDate;

	private double wSalePrice;

	private String barcode;

	private double balQty;

	private double packQty;

	private boolean discountRs;

	private long stock;

	private long product;

	private long grn;

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getFoc() {
		return foc;
	}

	public void setFoc(double foc) {
		this.foc = foc;
	}

	public float getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(float costPrice) {
		this.costPrice = costPrice;
	}

	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public double getwSalePrice() {
		return wSalePrice;
	}

	public void setwSalePrice(double wSalePrice) {
		this.wSalePrice = wSalePrice;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public double getBalQty() {
		return balQty;
	}

	public void setBalQty(double balQty) {
		this.balQty = balQty;
	}

	public double getPackQty() {
		return packQty;
	}

	public void setPackQty(double packQty) {
		this.packQty = packQty;
	}

	public boolean isDiscountRs() {
		return discountRs;
	}

	public void setDiscountRs(boolean discountRs) {
		this.discountRs = discountRs;
	}

	public long getStock() {
		return stock;
	}

	public void setStock(long stock) {
		this.stock = stock;
	}

	public long getProduct() {
		return product;
	}

	public void setProduct(long product) {
		this.product = product;
	}

	public long getGrn() {
		return grn;
	}

	public void setGrn(long grn) {
		this.grn = grn;
	}
	
	
}
