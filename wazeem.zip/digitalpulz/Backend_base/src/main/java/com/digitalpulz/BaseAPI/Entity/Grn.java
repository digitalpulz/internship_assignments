package com.digitalpulz.BaseAPI.Entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "b_grn")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Grn extends BaseEntityAudit{

	private String invoiceNo;
	
	private String purchaseOrderNo;
	
	private Date rcvDate;//receive date
	
	private boolean active;
	
	private double grossAmt;//gross amount
	
	private double netAmt;// net amount
	
	private double addition;
	
	private double deduction;
	
	@Column(columnDefinition = "double default 0")
	private double discount;
	
	private boolean discountRs;
	
	@Column(columnDefinition = "double default 0")
	private double totDiscount;//discount amount
	
	@OneToMany(fetch = FetchType.LAZY,
	          mappedBy = "grn")
	@JsonIgnoreProperties("grn")
	private Set<Grnitem> grnitem = new HashSet<>();

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getPurchaseOrderNo() {
		return purchaseOrderNo;
	}

	public void setPurchaseOrderNo(String purchaseOrderNo) {
		this.purchaseOrderNo = purchaseOrderNo;
	}

	public Date getRcvDate() {
		return rcvDate;
	}

	public void setRcvDate(Date rcvDate) {
		this.rcvDate = rcvDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public double getGrossAmt() {
		return grossAmt;
	}

	public void setGrossAmt(double grossAmt) {
		this.grossAmt = grossAmt;
	}

	public double getNetAmt() {
		return netAmt;
	}

	public void setNetAmt(double netAmt) {
		this.netAmt = netAmt;
	}

	public double getAddition() {
		return addition;
	}

	public void setAddition(double addition) {
		this.addition = addition;
	}

	public double getDeduction() {
		return deduction;
	}

	public void setDeduction(double deduction) {
		this.deduction = deduction;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public boolean isDiscountRs() {
		return discountRs;
	}

	public void setDiscountRs(boolean discountRs) {
		this.discountRs = discountRs;
	}

	public double getTotDiscount() {
		return totDiscount;
	}

	public void setTotDiscount(double totDiscount) {
		this.totDiscount = totDiscount;
	}

	public Set<Grnitem> getGrnitem() {
		return grnitem;
	}

	public void setGrnitem(Set<Grnitem> grnitem) {
		this.grnitem = grnitem;
	}
		
}
