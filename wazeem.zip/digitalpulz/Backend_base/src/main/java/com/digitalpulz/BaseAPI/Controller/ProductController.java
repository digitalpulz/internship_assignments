package com.digitalpulz.BaseAPI.Controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpulz.BaseAPI.Entity.Product;
import com.digitalpulz.BaseAPI.Model.RequestWrapper;
import com.digitalpulz.BaseAPI.Repository.ProductRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/Product")
public class ProductController {

	@Autowired
	ProductRepository productRepository;

	static final Logger logger = Logger.getLogger(ProductController.class);

	@PostMapping
	public Product add(@RequestBody RequestWrapper request) {
		logger.info("Add product method");
		try {
			Product product = new Product();

			product.setDangerLevel(request.getProduct().getDangerLevel());
			product.setProductCode(request.getProduct().getProductCode());
			product.setProductName(request.getProduct().getProductName());
			product.setReorderLevel(request.getProduct().getReorderLevel());
			product.setActive(request.getProduct().isActive());
			product.setCreatedBy(request.getProduct().getUser());
			product.setCreatedAt(new Date());

			return productRepository.save(product);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Add product method error: " + e.getMessage() + ", " + e.getCause());
			return null;
		}

	}
	
	@PutMapping(value = "/{id}")
	public ResponseEntity<Product> update(@PathVariable("id") Long id, @RequestBody RequestWrapper request) {
		return productRepository.findById(id).map(updateProduct -> {
			logger.info("Update product method");
			try {

				updateProduct.setDangerLevel(request.getProduct().getDangerLevel());
				updateProduct.setProductCode(request.getProduct().getProductCode());
				updateProduct.setProductName(request.getProduct().getProductName());
				updateProduct.setReorderLevel(request.getProduct().getReorderLevel());
				updateProduct.setUpdatedAt(new Date());
				updateProduct.setUpdatedBy(request.getProduct().getUser());

				productRepository.save(updateProduct);

				return ResponseEntity.ok().body(updateProduct);

			} catch (Exception ex) {
				ex.printStackTrace();
				logger.error("Update product method error: " + ex.getMessage() + ", " + ex.getCause());
				return null;
			}

		}).orElse(ResponseEntity.notFound().build());
	}

	@GetMapping(value = "/{id}")
	public Product getById(@PathVariable("id") Long id) {
		logger.info("Get product by id method");
		try {

			Product product = productRepository.findById(id).get();
			return product;
		} catch (Exception ex) {
			logger.error("Get product by id method error: " + ex.getMessage() + ", " + ex.getCause());
			return null;
		}
	}

	@GetMapping
	public List<Product> getAllActiveProduct() {
		logger.info("Get all active product method");
		try {

			Optional<List<Product>> productList = productRepository.getAllActiveProducts();
			if(productList.isPresent())
				return productList.get();
			else
				return null;
		} catch (Exception ex) {
			logger.error("Get all active product method error: " + ex.getMessage() + ", " + ex.getCause());
			return null;
		}
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Product> delete(@PathVariable("id") Long id, @RequestBody RequestWrapper request) {
		return productRepository.findById(id).map(updateProduct -> {
			logger.info("Delete product method");
			try {

				updateProduct.setActive(false);
				updateProduct.setUpdatedAt(new Date());
				updateProduct.setUpdatedBy(request.getProduct().getUser());

				productRepository.save(updateProduct);

				return ResponseEntity.ok().body(updateProduct);

			} catch (Exception ex) {
				ex.printStackTrace();
				logger.error("Delete product method error: " + ex.getMessage() + ", " + ex.getCause());
				return null;
			}

		}).orElse(ResponseEntity.notFound().build());
	}


}
