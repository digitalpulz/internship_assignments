package com.digitalpulz.BaseAPI.Entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "b_grn_item")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Grnitem extends BaseEntityAudit{

	private double quantity;
	
	private double foc;
	
	private float costPrice;
	
	private float sellingPrice;
	
	private float discount;
	
	private Date expDate;//expire date
	
	private boolean active;
	
	private double wSalePrice;//whole sale price
	
	private String barcode;
	
	private double balQty;
	
	private double packQty;	
	
	private boolean discountRs;//if discount Rs:true if discount presentage:false
	
	@OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "grnitem")
	@JsonIgnoreProperties("grnitem")
	private Stock stock;

	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product", nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	private Product product;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grn", nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	private Grn grn;

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getFoc() {
		return foc;
	}

	public void setFoc(double foc) {
		this.foc = foc;
	}

	public float getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(float costPrice) {
		this.costPrice = costPrice;
	}

	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public double getwSalePrice() {
		return wSalePrice;
	}

	public void setwSalePrice(double wSalePrice) {
		this.wSalePrice = wSalePrice;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public double getBalQty() {
		return balQty;
	}

	public void setBalQty(double balQty) {
		this.balQty = balQty;
	}

	public double getPackQty() {
		return packQty;
	}

	public void setPackQty(double packQty) {
		this.packQty = packQty;
	}

	public boolean isDiscountRs() {
		return discountRs;
	}

	public void setDiscountRs(boolean discountRs) {
		this.discountRs = discountRs;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Grn getGrn() {
		return grn;
	}

	public void setGrn(Grn grn) {
		this.grn = grn;
	}
		
}
