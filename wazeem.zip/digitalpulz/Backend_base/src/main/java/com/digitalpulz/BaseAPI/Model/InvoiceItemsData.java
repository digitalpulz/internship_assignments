package com.digitalpulz.BaseAPI.Model;

public class InvoiceItemsData extends BaseEntityData{

	private String particulars;

	private double rate;

	private double qty;
	
	private double amount;	

	private double discount;

	private boolean isDiscountRs;
	
	private long invoice;
	
	private long stock;

	public String getParticulars() {
		return particulars;
	}

	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getQty() {
		return qty;
	}

	public void setQty(double qty) {
		this.qty = qty;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public boolean isDiscountRs() {
		return isDiscountRs;
	}

	public void setDiscountRs(boolean isDiscountRs) {
		this.isDiscountRs = isDiscountRs;
	}

	public long getInvoice() {
		return invoice;
	}

	public void setInvoice(long invoice) {
		this.invoice = invoice;
	}

	public long getStock() {
		return stock;
	}

	public void setStock(long stock) {
		this.stock = stock;
	}
	
	
}
