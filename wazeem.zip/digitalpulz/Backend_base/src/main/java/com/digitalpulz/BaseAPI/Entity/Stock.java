package com.digitalpulz.BaseAPI.Entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "b_stock")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Stock extends BaseEntityAudit{

	private double quantity;
	
	private double remainq;//remaining quantity
	
	private float sellingPrice;
	
	private Date expDate;//expire date
		
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grnItem", nullable = false)
	@JsonIgnoreProperties("stock")
	private Grnitem grnitem;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stock")
	@JsonIgnoreProperties("stock")
	private Set<InvoiceItems> items = new HashSet<>();

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getRemainq() {
		return remainq;
	}

	public void setRemainq(double remainq) {
		this.remainq = remainq;
	}

	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public Grnitem getGrnitem() {
		return grnitem;
	}

	public void setGrnitem(Grnitem grnitem) {
		this.grnitem = grnitem;
	}

	public Set<InvoiceItems> getItems() {
		return items;
	}

	public void setItems(Set<InvoiceItems> items) {
		this.items = items;
	}
		
}
