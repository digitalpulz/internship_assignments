package com.digitalpulz.BaseAPI.Model;

import java.util.Date;

public class StockData extends BaseEntityData {

	private double quantity;

	private double remainq;

	private float sellingPrice;

	private Date expDate;

	private long grnitem;

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getRemainq() {
		return remainq;
	}

	public void setRemainq(double remainq) {
		this.remainq = remainq;
	}

	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public long getGrnitem() {
		return grnitem;
	}

	public void setGrnitem(long grnitem) {
		this.grnitem = grnitem;
	}
	
	
}
