package com.digitalpulz.BaseAPI.Model;

public class RequestWrapper {

	private GrnData grn;
	
	private GrnitemData grnItem;
	
	private InvoiceData invoice;
	
	private InvoiceItemsData invoiceItem;
	
	private ProductData product;
	
	private StockData stock;

	public GrnData getGrn() {
		return grn;
	}

	public void setGrn(GrnData grn) {
		this.grn = grn;
	}

	public GrnitemData getGrnItem() {
		return grnItem;
	}

	public void setGrnItem(GrnitemData grnItem) {
		this.grnItem = grnItem;
	}

	public InvoiceData getInvoice() {
		return invoice;
	}

	public void setInvoice(InvoiceData invoice) {
		this.invoice = invoice;
	}

	public InvoiceItemsData getInvoiceItem() {
		return invoiceItem;
	}

	public void setInvoiceItem(InvoiceItemsData invoiceItem) {
		this.invoiceItem = invoiceItem;
	}

	public ProductData getProduct() {
		return product;
	}

	public void setProduct(ProductData product) {
		this.product = product;
	}

	public StockData getStock() {
		return stock;
	}

	public void setStock(StockData stock) {
		this.stock = stock;
	}
	
	

}
