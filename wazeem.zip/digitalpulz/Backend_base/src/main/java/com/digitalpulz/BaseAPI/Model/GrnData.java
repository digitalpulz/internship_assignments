package com.digitalpulz.BaseAPI.Model;

import java.util.Date;

public class GrnData extends BaseEntityData {

	private String invoiceNo;

	private String purchaseOrderNo;

	private Date rcvDate;	

	private double grossAmt;

	private double netAmt;

	private double addition;

	private double deduction;

	private double discount;

	private boolean discountRs;

	private double totDiscount;

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getPurchaseOrderNo() {
		return purchaseOrderNo;
	}

	public void setPurchaseOrderNo(String purchaseOrderNo) {
		this.purchaseOrderNo = purchaseOrderNo;
	}

	public Date getRcvDate() {
		return rcvDate;
	}

	public void setRcvDate(Date rcvDate) {
		this.rcvDate = rcvDate;
	}
	
	public double getGrossAmt() {
		return grossAmt;
	}

	public void setGrossAmt(double grossAmt) {
		this.grossAmt = grossAmt;
	}

	public double getNetAmt() {
		return netAmt;
	}

	public void setNetAmt(double netAmt) {
		this.netAmt = netAmt;
	}

	public double getAddition() {
		return addition;
	}

	public void setAddition(double addition) {
		this.addition = addition;
	}

	public double getDeduction() {
		return deduction;
	}

	public void setDeduction(double deduction) {
		this.deduction = deduction;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public boolean isDiscountRs() {
		return discountRs;
	}

	public void setDiscountRs(boolean discountRs) {
		this.discountRs = discountRs;
	}

	public double getTotDiscount() {
		return totDiscount;
	}

	public void setTotDiscount(double totDiscount) {
		this.totDiscount = totDiscount;
	}
	
	
}
